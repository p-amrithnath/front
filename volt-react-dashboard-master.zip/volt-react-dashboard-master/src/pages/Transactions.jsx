import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch ,faPlus} from '@fortawesome/free-solid-svg-icons';
import { Col, Row, Form, Button, ButtonGroup,InputGroup,Dropdown} from '@themesberg/react-bootstrap';
import { TransactionsTable } from "../components/Tables";
import "./Transactions.css";

export default () => {
  return (
    <>
     <div>
        <h4>Team Members</h4>
        <p className="mb-0">All the members.</p>
     </div>
      <div className="d-flex justify-content-between align-items-center py-4 responsive-container">
        <Row className="justify-content-end">
          <Col>
            <InputGroup>
              <InputGroup.Text>
                <FontAwesomeIcon icon={faSearch} />
              </InputGroup.Text>
              <Form.Control type="text" placeholder="Search" />
            </InputGroup>
          </Col>
        </Row>
        <ButtonGroup>
          <Dropdown.Toggle as={Button} variant="primary" size="sm" className="me-2">
            <FontAwesomeIcon icon={faPlus} className="me-2" />New Member
          </Dropdown.Toggle>
        </ButtonGroup>
      </div>
      <TransactionsTable />
    </>
  );
};