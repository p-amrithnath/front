import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCashRegister,
  faChartLine,
  faCloudUploadAlt,
  faPlus,
  faRocket,
  faTasks,
  faUserShield,
} from "@fortawesome/free-solid-svg-icons";
import {
  Col,
  Row,
  Button,
  Dropdown,
  ButtonGroup,
} from "@themesberg/react-bootstrap";

import {
  ClockTimeWidget,
  CalenderWidget
} from "../../components/Widgets";
import { WelcomingComponent } from "../../components/Tables";
import { trafficShares, totalOrders } from "../../data/charts";
import "./Dashboard.css";

export default function DashboardOverview() {
  return (
    <>
      <Row>
        <Col xs={12} className="mb-4 custom-height">
          <WelcomingComponent employeeName="[Employee Name]" />
        </Col>
      </Row>
      <Row>
        <Col xs={12} md={6} className="mb-4 d-flex justify-content-start">
          <CalenderWidget />
        </Col>
        <Col xs={12} md={6} className="mb-4 d-flex justify-content-end">
          <ClockTimeWidget />
        </Col>
      </Row>
    </>
  );
}
