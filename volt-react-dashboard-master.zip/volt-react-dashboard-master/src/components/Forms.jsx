import React, { useState } from "react";
import moment from "moment-timezone";
import Datetime from "react-datetime";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCalendarAlt } from "@fortawesome/free-solid-svg-icons";
import {
  Col,
  Row,
  Card,
  Form,
  Button,
  InputGroup,
} from "@themesberg/react-bootstrap";
import Select from "react-select";

export const GeneralInfoForm = ({ edit }) => {
  const [birthday, setBirthday] = useState("");

  const [selectedSkills, setSelectedSkills] = useState([]);

  const skillsOptions = [
    { value: "JavaScript", label: "JavaScript" },
    { value: "Python", label: "Python" },
    { value: "Java", label: "Java" },
    { value: "C++", label: "C++" },
    // Add more skills as needed
  ];

  const handleSkillsChange = (selectedOptions) => {
    setSelectedSkills(selectedOptions);
  };

  return (
    <Card border="light" className="bg-white shadow-sm mb-4">
      <Card.Body>
        <h5 className="mb-4">General information</h5>
        <Form>
          <Row>
            <Col md={6} className="mb-3">
              <Form.Group id="firstName">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Enter your first name"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
            <Col md={6} className="mb-3">
              <Form.Group id="birthday">
                <Form.Label>DOB</Form.Label>
                <Datetime
                  timeFormat={false}
                  onChange={setBirthday}
                  renderInput={(props, openCalendar) => (
                    <InputGroup>
                      <InputGroup.Text>
                        <FontAwesomeIcon icon={faCalendarAlt} />
                      </InputGroup.Text>
                      <Form.Control
                        required
                        type="text"
                        value={
                          birthday ? moment(birthday).format("MM/DD/YYYY") : ""
                        }
                        placeholder="mm/dd/yyyy"
                        onFocus={openCalendar}
                        onChange={() => {}}
                        disabled={!edit}
                      />
                    </InputGroup>
                  )}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row className="align-items-center">
            <Col md={6} className="mb-3">
              <Form.Group id="gender">
                <Form.Label>Gender</Form.Label>
                <Form.Select defaultValue="0" disabled={!edit}>
                  <option value="0">Gender</option>
                  <option value="1">Female</option>
                  <option value="2">Male</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col md={6} className="mb-3">
              <Form.Group id="lastName">
                <Form.Label>Blood Group</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Blood Group"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col md={6} className="mb-3">
              <Form.Group id="emal">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  required
                  type="email"
                  placeholder="name@company.com"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
            <Col md={6} className="mb-3">
              <Form.Group id="phone">
                <Form.Label>Phone</Form.Label>
                <Form.Control
                  required
                  type="number"
                  placeholder="+12-345 678 910"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
          </Row>

          <h5 className="my-4">Address</h5>
          <Row>
            <Col sm={9} className="mb-3">
              <Form.Group id="address">
                <Form.Label>Address</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="Enter your home address"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
            <Col sm={3} className="mb-3">
              <Form.Group id="addressNumber">
                <Form.Label>Number</Form.Label>
                <Form.Control
                  required
                  type="number"
                  placeholder="No."
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={4} className="mb-3">
              <Form.Group id="city">
                <Form.Label>City</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="City"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
            <Col sm={4} className="mb-3">
              <Form.Group className="mb-2">
                <Form.Label>Select state</Form.Label>
                <Form.Select id="state" defaultValue="0" disabled={!edit}>
                  <option value="0">State</option>
                  <option value="AL">Alabama</option>
                  <option value="AK">Alaska</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col sm={4}>
              <Form.Group id="zip">
                <Form.Label>ZIP</Form.Label>
                <Form.Control
                  required
                  type="tel"
                  placeholder="ZIP"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
          </Row>
          <h5 className="my-4">Company</h5>
          <Row>
            <Col md={6} className="mb-3">
              <Form.Group id="address">
                <Form.Label>Designation</Form.Label>
                <Form.Control
                  required
                  type="text"
                  placeholder="designation"
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
            <Col sm={3} className="mb-3">
              <Form.Group id="Date Of Joining">
                <Form.Label>DOB</Form.Label>
                <Datetime
                  timeFormat={false}
                  onChange={setBirthday}
                  renderInput={(props, openCalendar) => (
                    <InputGroup>
                      <InputGroup.Text>
                        <FontAwesomeIcon icon={faCalendarAlt} />
                      </InputGroup.Text>
                      <Form.Control
                        required
                        type="text"
                        value={
                          birthday ? moment(birthday).format("MM/DD/YYYY") : ""
                        }
                        placeholder="mm/dd/yyyy"
                        onFocus={openCalendar}
                        onChange={() => {}}
                        disabled={!edit}
                      />
                    </InputGroup>
                  )}
                />
              </Form.Group>
            </Col>
            <Col sm={3} className="mb-3">
              <Form.Group id="yoe">
                <Form.Label>Year OF Experience</Form.Label>
                <Form.Control
                  required
                  type="number"
                  placeholder="No."
                  disabled={!edit}
                />
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col sm={4} className="mb-3">
              <Form.Group className="mb-2">
                <Form.Label>Work Mode</Form.Label>
                <Form.Select id="state" defaultValue="0" disabled={!edit}>
                  <option value="0">Remote</option>
                  <option value="AK">On Site</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col sm={4} className="mb-3">
              <Form.Group className="mb-2">
                <Form.Label>Employement Type</Form.Label>
                <Form.Select id="state" defaultValue="0" disabled={!edit}>
                  <option value="0">Permanent</option>
                  <option value="AK">Contract</option>
                  <option value="AK">Intern</option>
                  <option value="AK">Trainee</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col sm={4}>
  <Form.Group className="mb-2">
    <Form.Label>Skills</Form.Label>
    <Select
      isMulti
      value={selectedSkills}
      onChange={handleSkillsChange}
      options={skillsOptions}
      isDisabled={!edit}
    />
  </Form.Group>
</Col>
          </Row>
          {edit && (
  <div className="mt-3">
    <Button variant="primary" type="submit">
      Save All
    </Button>
  </div>
)}
        </Form>
      </Card.Body>
    </Card>
  );
};
